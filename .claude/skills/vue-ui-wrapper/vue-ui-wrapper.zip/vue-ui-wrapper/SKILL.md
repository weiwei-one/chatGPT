---
name: vue-ui-wrapper
description: Use this skill when creating, reviewing, or refactoring Vue 3 UI library wrapper components. It covers props, emits, attrs passthrough, slots, v-model, defineModel, ref/defineExpose, composable reuse, lodash, and VueUse. Use it for Element Plus, Naive UI, Ant Design Vue, Vant, Arco Design Vue, or similar Vue UI libraries.
---

# Vue 3 UI Wrapper Skill

## Goal

Create lightweight, maintainable Vue 3 UI library wrapper components.

The wrapper should:

- unify project defaults
- reduce repeated code
- preserve necessary underlying UI component capabilities
- avoid over-engineering
- reuse logic through composables
- avoid introducing unnecessary new dependencies

## Project Constraints

The project currently uses:

- Vue 3
- TypeScript
- lodash
- @vueuse/core

Do not introduce heavy new libraries by default, such as:

- @tanstack/vue-query
- vue-request
- vue-hooks-plus
- other request-state libraries

Only suggest new dependencies when the user explicitly asks or when the project clearly needs caching, retries, stale data handling, or cross-page server-state sharing.

## Core Principle

```txt
谁拥有语义，谁声明；
谁只是路过，谁透传；
谁需要命令式调用，谁 expose；
谁是复用状态逻辑，谁抽 composable；
谁是通用数据处理，优先用 lodash；
谁是 Vue 响应式工具，优先用 VueUse；
不要为了“最佳实践”额外引入重型依赖。
```

## When To Use This Skill

Use this skill when the task involves:

- wrapping UI library components
- creating BaseInput / BaseSelect / BaseButton / BaseDialog / BaseTable
- creating business components like UserSelect / DictSelect / PermissionButton
- designing props / emits / slots / attrs passthrough
- deciding whether to use defineModel or attrs passthrough
- exposing component methods through defineExpose
- extracting repeated logic into composables
- reviewing existing wrapper components

## Required Workflow

Before generating code, classify the component:

1. Base component
2. Business component
3. Scene component

Then decide:

1. Which props should be declared?
2. Which props should be passed through by attrs?
3. Which events should be emitted?
4. Which events should only be passed through?
5. Should v-model be handled by defineModel or attrs?
6. Which slots should be preserved or exposed?
7. Should ref / defineExpose be used?
8. Is there repeated logic that should become a composable?
9. Can existing lodash or VueUse utilities solve the problem?
10. Is the solution still lightweight?

## Reference Files

Read these files when needed:

- `references/component-types.md`
- `references/props-emits.md`
- `references/attrs-slots.md`
- `references/model-ref-expose.md`
- `references/composables.md`
- `references/dependencies.md`
- `references/checklist.md`

## Example Files

Use these examples as implementation patterns:

- `examples/BaseInput.vue`
- `examples/BaseDialog.vue`
- `examples/ActionButton.vue`
- `examples/BaseTable.vue`
- `examples/UserSelect.vue`
- `examples/useAttrsSplit.ts`
- `examples/useActionLoading.ts`
- `examples/useRemoteOptions.ts`
- `examples/useTableRequest.ts`
- `examples/cleanQuery.ts`

## Output Requirements

When creating or refactoring a wrapper component, output:

1. Component source code
2. Composable source code, if needed
3. Usage example
4. Props explanation
5. Emits explanation
6. Attrs passthrough explanation
7. Slots explanation
8. Ref / expose explanation
9. Design rationale
10. Gotchas

## Hard Rules

- Do not redeclare all props from the underlying UI component.
- Do not pass `$attrs` to multiple targets.
- Do not expose raw internal UI component instances by default.
- Do not place business logic inside Base components.
- Do not create composables unless they simplify repeated logic.
- Do not introduce new dependencies unless explicitly requested.
- Prefer Vue native APIs for simple state.
- Prefer VueUse for Vue-related reusable behavior.
- Prefer lodash for pure data utilities.
