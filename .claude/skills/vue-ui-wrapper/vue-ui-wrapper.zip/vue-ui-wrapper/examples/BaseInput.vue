<script setup lang="ts">
import { ref } from 'vue'

defineOptions({
  inheritAttrs: false
})

const model = defineModel<string | number>()

const inputRef = ref<any>()

function focus() {
  inputRef.value?.focus?.()
}

function blur() {
  inputRef.value?.blur?.()
}

function clear() {
  model.value = ''
}

defineExpose({
  focus,
  blur,
  clear
})
</script>

<template>
  <ElInput
    ref="inputRef"
    v-model="model"
    clearable
    v-bind="$attrs"
  >
    <template
      v-for="(_, name) in $slots"
      #[name]="slotProps"
    >
      <slot
        :name="name"
        v-bind="slotProps"
      />
    </template>
  </ElInput>
</template>
