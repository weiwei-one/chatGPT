import { computed, useAttrs } from 'vue'

export function useAttrsSplit(rootKeys: string[] = ['class', 'style']) {
  const attrs = useAttrs()

  const rootAttrs = computed(() => {
    const result: Record<string, unknown> = {}

    for (const key of rootKeys) {
      if (key in attrs) {
        result[key] = attrs[key]
      }
    }

    return result
  })

  const innerAttrs = computed(() => {
    const result: Record<string, unknown> = {}

    for (const key in attrs) {
      if (!rootKeys.includes(key)) {
        result[key] = attrs[key]
      }
    }

    return result
  })

  return {
    attrs,
    rootAttrs,
    innerAttrs
  }
}
