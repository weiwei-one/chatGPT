<script setup lang="ts">
import { useRemoteOptions } from '@/composables/ui/useRemoteOptions'
import { searchUsers } from '@/api/user'

defineOptions({
  inheritAttrs: false
})

const model = defineModel<string | number>()

const {
  options,
  loading,
  search,
  load
} = useRemoteOptions(
  searchUsers,
  user => ({
    label: user.name,
    value: user.id
  })
)

function reload() {
  load()
}

defineExpose({
  reload
})
</script>

<template>
  <ElSelect
    v-model="model"
    v-bind="$attrs"
    :loading="loading"
    filterable
    remote
    clearable
    :remote-method="search"
  >
    <ElOption
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value"
      :disabled="item.disabled"
    />
  </ElSelect>
</template>
