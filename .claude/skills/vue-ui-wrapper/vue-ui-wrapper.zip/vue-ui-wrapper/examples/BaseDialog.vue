<script setup lang="ts">
defineOptions({
  inheritAttrs: false
})

const visible = defineModel<boolean>()

const props = withDefaults(
  defineProps<{
    confirmText?: string
    cancelText?: string
    confirmLoading?: boolean
    showFooter?: boolean
  }>(),
  {
    confirmText: '确定',
    cancelText: '取消',
    confirmLoading: false,
    showFooter: true
  }
)

const emit = defineEmits<{
  confirm: []
  cancel: []
}>()

function open() {
  visible.value = true
}

function close() {
  visible.value = false
}

function handleCancel() {
  emit('cancel')
  close()
}

defineExpose({
  open,
  close
})
</script>

<template>
  <ElDialog
    v-model="visible"
    width="600px"
    destroy-on-close
    v-bind="$attrs"
  >
    <template
      v-if="$slots.header"
      #header
    >
      <slot name="header" />
    </template>

    <slot />

    <template
      v-if="props.showFooter"
      #footer
    >
      <slot name="footer">
        <ElButton @click="handleCancel">
          {{ props.cancelText }}
        </ElButton>

        <ElButton
          type="primary"
          :loading="props.confirmLoading"
          @click="emit('confirm')"
        >
          {{ props.confirmText }}
        </ElButton>
      </slot>
    </template>
  </ElDialog>
</template>
