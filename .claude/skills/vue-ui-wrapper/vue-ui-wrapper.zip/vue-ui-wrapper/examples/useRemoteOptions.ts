import { ref } from 'vue'
import { useDebounceFn } from '@vueuse/core'

export type OptionItem = {
  label: string
  value: string | number
  disabled?: boolean
}

export function useRemoteOptions<T>(
  request: (keyword?: string) => Promise<T[]>,
  mapper: (item: T) => OptionItem,
  delay = 300
) {
  const options = ref<OptionItem[]>([])
  const loading = ref(false)

  async function load(keyword?: string) {
    loading.value = true

    try {
      const list = await request(keyword)
      options.value = list.map(mapper)
    } finally {
      loading.value = false
    }
  }

  const search = useDebounceFn((keyword: string) => {
    load(keyword)
  }, delay)

  return {
    options,
    loading,
    load,
    search
  }
}
