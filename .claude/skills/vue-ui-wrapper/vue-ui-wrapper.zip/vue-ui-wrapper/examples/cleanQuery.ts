import omitBy from 'lodash/omitBy'
import isNil from 'lodash/isNil'

export function cleanQuery<T extends Record<string, unknown>>(query: T) {
  return omitBy(query, value => {
    return value === '' || isNil(value)
  })
}
