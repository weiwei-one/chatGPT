import { reactive, ref } from 'vue'
import { cleanQuery } from '@/utils/query'

export type PageResult<T> = {
  list: T[]
  total: number
}

export type PageQuery = {
  page: number
  pageSize: number
  [key: string]: unknown
}

export function useTableRequest<T, Q extends PageQuery>(
  request: (query: Partial<Q>) => Promise<PageResult<T>>,
  initialQuery: Q
) {
  const query = reactive({ ...initialQuery }) as Q
  const list = ref<T[]>([])
  const total = ref(0)
  const loading = ref(false)

  async function fetchList() {
    loading.value = true

    try {
      const params = cleanQuery({ ...query }) as Partial<Q>
      const result = await request(params)

      list.value = result.list
      total.value = result.total
    } finally {
      loading.value = false
    }
  }

  function reload() {
    fetchList()
  }

  function resetQuery() {
    Object.assign(query, initialQuery)
    fetchList()
  }

  function handlePageChange(page: number) {
    query.page = page
    fetchList()
  }

  function handlePageSizeChange(pageSize: number) {
    query.pageSize = pageSize
    query.page = 1
    fetchList()
  }

  return {
    query,
    list,
    total,
    loading,
    fetchList,
    reload,
    resetQuery,
    handlePageChange,
    handlePageSizeChange
  }
}
