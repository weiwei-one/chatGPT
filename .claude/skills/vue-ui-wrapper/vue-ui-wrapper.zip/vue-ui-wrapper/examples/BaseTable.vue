<script setup lang="ts" generic="T extends Record<string, any>">
defineOptions({
  inheritAttrs: false
})

export type TableColumn<T = any> = {
  prop?: keyof T | string
  label: string
  width?: string | number
  minWidth?: string | number
  fixed?: boolean | 'left' | 'right'
  align?: 'left' | 'center' | 'right'
  slot?: string
}

const props = defineProps<{
  data: T[]
  columns: TableColumn<T>[]
  loading?: boolean
}>()

defineSlots<{
  default?: () => any
  [key: string]: ((props: { row: T; column: unknown; $index: number }) => any) | undefined
}>()
</script>

<template>
  <ElTable
    v-loading="props.loading"
    :data="props.data"
    v-bind="$attrs"
  >
    <ElTableColumn
      v-for="column in props.columns"
      :key="String(column.prop || column.label)"
      :prop="column.prop as string"
      :label="column.label"
      :width="column.width"
      :min-width="column.minWidth"
      :fixed="column.fixed"
      :align="column.align"
    >
      <template
        v-if="column.slot"
        #default="scope"
      >
        <slot
          :name="column.slot"
          v-bind="scope"
        />
      </template>
    </ElTableColumn>

    <slot />
  </ElTable>
</template>
