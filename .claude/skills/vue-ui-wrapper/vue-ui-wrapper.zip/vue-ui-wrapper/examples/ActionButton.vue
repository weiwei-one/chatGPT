<script setup lang="ts">
import { useActionLoading } from '@/composables/ui/useActionLoading'

defineOptions({
  inheritAttrs: false
})

const props = defineProps<{
  action?: () => Promise<unknown> | unknown
}>()

const emit = defineEmits<{
  success: []
  error: [error: unknown]
}>()

const { loading, run } = useActionLoading()

async function handleClick() {
  if (!props.action) return

  try {
    await run(props.action)
    emit('success')
  } catch (error) {
    emit('error', error)
  }
}
</script>

<template>
  <ElButton
    v-bind="$attrs"
    :loading="loading"
    @click="handleClick"
  >
    <slot />
  </ElButton>
</template>
