import { ref } from 'vue'

export function useActionLoading() {
  const loading = ref(false)

  async function run<T>(action: () => Promise<T> | T): Promise<T | undefined> {
    if (loading.value) return

    try {
      loading.value = true
      return await action()
    } finally {
      loading.value = false
    }
  }

  return {
    loading,
    run
  }
}
