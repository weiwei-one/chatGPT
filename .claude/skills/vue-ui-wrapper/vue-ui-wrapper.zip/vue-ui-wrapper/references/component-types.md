# Component Types

## Base Component

Examples:

- BaseButton
- BaseInput
- BaseSelect
- BaseDialog
- BaseTable
- BaseForm

Characteristics:

- light wrapper
- few custom props
- few custom emits
- heavy attrs passthrough
- heavy slots passthrough
- little or no business logic
- only unifies default behavior, style, or basic interaction

Rules:

- Keep it close to the underlying UI component.
- Do not block normal UI component usage.
- Do not redeclare all underlying UI props.
- Do not put complex business logic here.
- Use attrs and slots passthrough heavily.

## Business Component

Examples:

- UserSelect
- DeptSelect
- DictSelect
- StatusTag
- MoneyInput
- PermissionButton
- RemoteUserSelect

Characteristics:

- has business meaning
- declares business props
- declares business events
- moderately passes through UI capabilities
- may use composables for reusable business logic

Rules:

- Business props must be explicit.
- UI props may be passed through by attrs.
- Remote data, dict data, permissions, and option mapping should be extracted into composables when reusable.

## Scene Component

Examples:

- CreateUserDialog
- OrderSearchPanel
- ApprovalForm
- UserEditDrawer
- RolePermissionTree

Characteristics:

- full business scenario
- owns its API
- limited passthrough
- exposes only key slots
- exposes few or no refs

Rules:

- Do not expose all underlying UI library details.
- Do not allow callers to bypass business constraints.
- Design the API around the business scenario.
