# Composable Rules

## Core Principle

Components handle UI structure and external API.

Composables handle reusable state logic.

Utils and lodash handle pure data processing.

## Component Responsibilities

Components should handle:

- template structure
- props
- emits
- attrs
- slots
- v-model
- defineExpose
- default styling
- interaction entry points

## Composable Responsibilities

Composables should handle:

- loading
- dialog visible state
- pagination
- request flow
- remote options
- selection
- debounced search
- submit lock
- form process

## Utils / lodash Responsibilities

Utilities should handle:

- clean query
- clone
- pick
- omit
- compare
- group
- merge
- format
- transform

## When To Extract A Composable

Extract when:

- similar logic appears more than once
- logic can run independently from template structure
- logic contains state and process
- logic should be tested independently
- component becomes too large because of logic

## When Not To Extract

Do not extract when:

- used only once
- extraction requires too many parameters
- logic heavily depends on current template
- business is unstable
- the abstraction name is unclear

The extraction should make call sites simpler, not more complex.

## Recommended Project Composables

- useAttrsSplit
- useDialog
- useActionLoading
- useRemoteOptions
- useTableRequest
- useSelection
- useFormExpose
