# v-model, Ref, and Expose Rules

## v-model

For Vue 3.4+, use `defineModel` when the wrapper owns the model.

Example:

```ts
const model = defineModel<string | number>()
```

Good for:

- BaseInput
- BaseSelect
- BaseSwitch
- BaseDialog
- BaseDrawer

## Transparent v-model Passthrough

For ultra-thin wrappers, attrs passthrough is acceptable:

```vue
<ElInput
  clearable
  v-bind="$attrs"
/>
```

Then:

```vue
<BaseInput v-model="form.name" />
```

will pass `modelValue` and `update:modelValue` through attrs to `ElInput`.

## Do Not Mix Model Ownership

For the same model, choose one strategy:

- attrs passthrough
- defineModel ownership

Do not read `$attrs.modelValue` when already using `defineModel` for the same model.

Bad:

```vue
<ElInput
  v-model="model"
  :model-value="$attrs.modelValue"
  v-bind="$attrs"
/>
```

## Multiple v-model

```ts
const visible = defineModel<boolean>()
const loading = defineModel<boolean>('loading')
```

Usage:

```vue
<BaseDialog
  v-model="visible"
  v-model:loading="saving"
/>
```

## defineModel Default

Be careful with:

```ts
const model = defineModel<string>({
  default: ''
})
```

Prefer parent initialization:

```ts
const name = ref('')
```

## Ref and defineExpose

Do not assume parent refs automatically reach the inner UI component.

In `<script setup>`, expose stable methods with `defineExpose`.

Recommended:

```ts
defineExpose({
  focus,
  blur,
  clear
})
```

Do not expose the raw internal UI instance by default:

```ts
defineExpose({
  inputRef
})
```

Reason:

- parent becomes coupled to implementation details
- changing UI libraries becomes harder
- wrapper boundary becomes weak

Expose stable abstract methods:

- Input: focus / blur / clear
- Form: validate / resetFields / clearValidate
- Dialog: open / close
- Table: reload / clearSelection / toggleRowSelection
- Upload: submit / clearFiles
