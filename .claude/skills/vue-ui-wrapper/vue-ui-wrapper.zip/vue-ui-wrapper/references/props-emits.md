# Props and Emits Rules

## Props

Declare a prop only when the current wrapper component consumes it.

Declare props when the component needs to:

- render it
- compute from it
- branch logic on it
- enforce business constraints with it

Do not redeclare all props from the underlying UI component.

Bad:

```ts
defineProps<{
  placeholder?: string
  clearable?: boolean
  disabled?: boolean
  maxlength?: number
  showWordLimit?: boolean
  prefixIcon?: string
  suffixIcon?: string
}>()
```

Good:

```ts
defineProps<{
  label?: string
  required?: boolean
}>()
```

Underlying UI props should generally pass through `$attrs`.

If a prop is declared and still needs to reach the inner component, bind it manually:

```vue
<ElButton
  v-bind="$attrs"
  :disabled="props.disabled"
/>
```

A declared prop will not automatically appear in `$attrs`.

## Default Override Order

Allow external override:

```vue
<ElButton
  type="primary"
  v-bind="$attrs"
>
  <slot />
</ElButton>
```

Force internal value:

```vue
<ElButton
  v-bind="$attrs"
  type="primary"
>
  <slot />
</ElButton>
```

Default policy:

- Base components: defaults are usually overridable.
- Business components: some defaults may be locked.
- Scene components: business constraints should usually be locked.

## Emits

Do not declare emits for events that only pass through to the inner UI component.

For passthrough events, use attrs:

```vue
<ElButton v-bind="$attrs">
  <slot />
</ElButton>
```

Declare emits only when the wrapper:

- renames the event
- intercepts the event
- validates the event
- adds analytics
- debounces or throttles the event
- prevents duplicate submission
- emits business events

Business events should be explicit:

```ts
const emit = defineEmits<{
  confirm: []
  cancel: []
  success: []
  error: [error: unknown]
}>()
```

If an event is declared in `defineEmits`, it will not automatically pass through `$attrs`.

So this requires manual forwarding:

```vue
<script setup lang="ts">
const emit = defineEmits<{
  click: [event: MouseEvent]
}>()
</script>

<template>
  <ElButton @click="emit('click', $event)">
    <slot />
  </ElButton>
</template>
```

## Async Click Loading

Do not rely on:

```ts
await emit('click')
```

`emit` cannot reliably await the parent listener.

For async loading buttons, prefer an `action` prop:

```ts
const props = defineProps<{
  action?: () => Promise<unknown> | unknown
}>()
```
