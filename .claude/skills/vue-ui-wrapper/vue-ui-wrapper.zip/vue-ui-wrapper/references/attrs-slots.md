# Attrs and Slots Rules

## Attrs

All wrapper components should usually use:

```ts
defineOptions({
  inheritAttrs: false
})
```

Reason:

- avoid attrs falling onto the wrong root element
- avoid duplicated class / style / id / listeners
- let the wrapper decide where attrs belong

## Base Component Attrs

For thin Base components, pass attrs directly to the inner UI component:

```vue
<ElInput
  clearable
  v-bind="$attrs"
/>
```

## Wrapper DOM Attrs

If the component has an outer wrapper, split attrs:

```vue
<div
  class="base-field-input"
  v-bind="rootAttrs"
>
  <ElInput v-bind="innerAttrs" />
</div>
```

Usually:

- class / style go to root
- placeholder / clearable / maxlength / listeners go to inner UI component

Use `useAttrsSplit` for this.

## Do Not Duplicate Attrs

Bad:

```vue
<div v-bind="$attrs">
  <ElInput v-bind="$attrs" />
</div>
```

Problems:

- duplicated id
- unclear class behavior
- duplicated event triggering
- invalid attrs on DOM
- difficult debugging

## Slots

Default slot preserves content customization:

```vue
<ElButton v-bind="$attrs">
  <slot />
</ElButton>
```

Named slots expose fixed regions:

- header
- footer
- toolbar
- extra
- empty
- append
- prefix
- suffix
- actions

Scoped slots are used when the component provides data and the caller controls rendering.

Common scenarios:

- table row
- list item
- tree node
- select option
- upload item

Example:

```vue
<slot
  name="actions"
  :row="row"
  :index="index"
/>
```

## Batch Slot Passthrough

Allowed for Base components:

```vue
<template
  v-for="(_, name) in $slots"
  #[name]="slotProps"
>
  <slot
    :name="name"
    v-bind="slotProps"
  />
</template>
```

Use carefully:

- good for thin Base components
- not ideal for strong business components
- weaker type hints
- explicit slots are clearer for complex components

## defineSlots

Use `defineSlots` for complex components:

```ts
defineSlots<{
  default?: () => any
  footer?: () => any
  actions?: (props: { row: User; index: number }) => any
}>()
```
