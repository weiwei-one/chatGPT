# Wrapper Checklist

## Component Type

- [ ] Is this Base / Business / Scene?
- [ ] Is the API consistent with the component type?
- [ ] Is the wrapper still lightweight?

## Props

- [ ] Are only consumed props declared?
- [ ] Are underlying UI props avoided unless needed?
- [ ] If a declared prop is needed by the inner component, is it manually bound?
- [ ] Is default override order correct?

## Emits

- [ ] Are passthrough events left undeclared?
- [ ] Are business events explicitly declared?
- [ ] If an event is declared, is it manually emitted?
- [ ] Is async loading not based on `emit('click')`?

## Attrs

- [ ] Is `inheritAttrs: false` used?
- [ ] Are attrs passed to one clear target?
- [ ] If there is a wrapper DOM, are class/style split correctly?
- [ ] Is `$attrs` not duplicated across multiple elements?

## v-model

- [ ] Does the component own the model?
- [ ] If yes, is `defineModel` used?
- [ ] If ultra-thin, is attrs passthrough acceptable?
- [ ] Is the same model not mixed between defineModel and attrs?
- [ ] Is `defineModel default` used carefully?

## Slots

- [ ] Is default slot preserved?
- [ ] Are named slots needed?
- [ ] Are scoped slots needed for row/item/node rendering?
- [ ] Is batch slot passthrough only used for Base components?
- [ ] Is `defineSlots` used for complex components?

## Ref / Expose

- [ ] Is ref really needed?
- [ ] Is `defineExpose` used?
- [ ] Are only stable methods exposed?
- [ ] Is the raw internal UI instance not exposed by default?

## Composable

- [ ] Is repeated logic extracted?
- [ ] Is extraction actually simpler?
- [ ] Are VueUse and lodash used where appropriate?
- [ ] Are new dependencies avoided?
