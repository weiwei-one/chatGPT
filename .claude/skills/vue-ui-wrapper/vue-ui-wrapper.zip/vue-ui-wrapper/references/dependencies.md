# Dependency Rules

## Existing Dependencies

The project already uses:

- lodash
- @vueuse/core

Do not introduce new heavy dependencies by default.

## lodash

Use lodash for pure JavaScript data utilities.

Prefer method imports:

```ts
import cloneDeep from 'lodash/cloneDeep'
import omitBy from 'lodash/omitBy'
import isNil from 'lodash/isNil'
import pick from 'lodash/pick'
import debounce from 'lodash/debounce'
```

Avoid new code using:

```ts
import _ from 'lodash'
```

unless the project already requires this style.

Good lodash use cases:

- cloneDeep
- pick
- omit
- omitBy
- isEqual
- isNil
- groupBy
- uniqBy
- merge
- debounce
- throttle

## VueUse

Use VueUse for Vue-related reusable behavior.

Allowed common utilities:

- useDebounceFn
- useThrottleFn
- useAsyncState
- useLocalStorage
- useEventListener
- onClickOutside
- useElementSize

Do not use VueUse just to look advanced.

For simple state, use Vue native APIs:

```ts
const visible = ref(false)
const loading = ref(false)
const keyword = ref('')
```

## Do Not Add By Default

Do not add these by default:

- @tanstack/vue-query
- vue-request
- vue-hooks-plus
- other request-state libraries

Only suggest them when the user explicitly needs:

- request cache
- retry
- stale data
- cross-page server-state sharing
- complex pagination cache
- background refetch
